package com.example.aimassistlab

import android.annotation.SneakyThrows

class NativeInterface {
    // Load the native library
    companion object {
        init {
            System.loadLibrary("memory-injector")
        }
    }

    @SneakyThrows
    fun readMemory(pid: Int, address: Long): Long {
        return read_memory(pid, address)
    }

    @SneakyThrows
    fun writeMemory(pid: Int, address: Long, data: Long): Int {
        return write_memory(pid, address, data)
    }

    @SneakyThrows
    fun findProcessByName(name: String): Int {
        return find_process(name)
    }

    @SneakyThrows
    fun injectCode(pid: Int, address: Long, hook: Long): Int {
        // Write hook at target address
        return write_memory(pid, address, hook)
    }
}
