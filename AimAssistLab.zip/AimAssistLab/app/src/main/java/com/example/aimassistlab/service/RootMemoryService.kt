package com.example.aimassistlab.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import com.example.aimassistlab.R
import com.example.aimassistlab.nativeLib.memory_injector

class RootMemoryService : Service() {

    private var targetPid: Int = 0
    private var isInjecting: Boolean = false

    override fun onCreate() {
        super.onCreate()
        Log.d("RootMemoryService", "Root memory service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBBinder {
        return object : IBinder() {
            // Binder interface for memory injection commands
        }
    }

    /**
     * Find target game process by package name and return its PID
     */
    private fun findGamePid(packageName: Int): Int {
        // Read /proc to find process PID by package name
        val cmdlineFile = "/proc/${packageName}/cmdline"
        // In production, would scan /proc directory
        return 0
    }

    /**
     * Read memory at specified address from target process using ptrace
     * Requires root privileges
     */
    @SneakyThrows
    private fun readProcessMemory(pid: Int, address: Long): Long {
        // Attach to process
        android.os.Ptrace.attach(pid)
        Thread.sleep(500)
        
        // Read memory
        val data = memory_injector.read_memory(pid, address)
        
        // Detach
        android.os.Ptrace.detach(pid)
        Thread.sleep(500)
        
        return data
    }

    /**
     * Write memory at specified address to target process using ptrace
     * Requires root privileges
     */
    @SneakyThrows
    private fun writeProcessMemory(pid: Int, address: Long, data: Long) {
        // Attach to process
        android.os.Ptrace.attach(pid)
        Thread.sleep(500)
        
        // Write memory
        memory_injector.write_memory(pid, address, data)
        
        // Detach
        android.os.Ptrace.detach(pid)
        Thread.sleep(500)
    }

    /**
     * Inject code into target game process
     * This is called when the superuser approval is granted
     */
    @SneakyThrows
    fun injectIntoGame(packageName: String, targetAddress: Long) {
        if (isInjecting) return
        isInjecting = true

        try {
            // Find target process PID
            targetPid = findProcessByPackage(packageName)
            if (targetPid == 0) {
                Log.e("RootMemoryService", "Target process not found: $packageName")
                return
            }

            Log.d("RootMemoryService", "Found target process PID: $targetPid")

            // Verify we have root access
            if (!isRootAvailable()) {
                Log.e("RootMemoryService", "Root access not available")
                return
            }

            // Read current memory at target address
            val currentData = readProcessMemory(targetPid, targetAddress)
            Log.d("RootMemoryService", "Read current memory: 0x${currentData.toHexString()}")

            // Write hook/jump code at target address
            // This is a simplified example - real implementation would
            // write proper assembly hook
            val hookBytes = intArrayOf(0xE3, 0x00, 0x00, 0x00)  // MOV instruction example
            writeProcessMemory(targetPid, targetAddress, *(hookBytes.toLongArray()))

            Log.d("RootMemoryService", "Memory injection completed at address: 0x${targetAddress.toHexString()}")
        } catch (e: Exception) {
            Log.e("RootMemoryService", "Injection error: ${e.message}")
        } finally {
            isInjecting = false
        }
    }

    /**
     * Check if root/superuser access is available
     */
    private fun isRootAvailable(): Boolean {
        return Runtime.getRuntime().exec(
            arrayOf("su", "-c", "id")
        ).inputStream().readText().contains("uid=0")
    }

    /**
     * Find process PID by package name
     */
    private fun findProcessByPackage(packageName: String): Int {
        // Scan /proc directory for matching process
        val procDir = File("/proc")
        if (!procDir.exists()) return 0

        procDir.listFiles()?.forEach { dir ->
            if (dir.name.toInt() > 0) {
                val cmdline = File(dir, "cmdline")
                if (cmdline.exists()) {
                    cmdline.readText().contains(packageName) && dir.name.toInt() ?: run {
                        // Found matching process
                        return@forEach dir.name.toInt()
                    }
                }
            }
        }
        return 0
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("RootMemoryService", "Root memory service destroyed")
        if (targetPid > 0) {
            try {
                android.os.Ptrace.detach(targetPid, 0, 0)
            } catch (_: Exception) {}
        }
    }
}