#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/unistd.h>
#include <linux/elf.h>
#include <string.h>
#include <stdio.h>
#include <stdlib>

// Read memory at address from target process
long read_memory(pid_t pid, unsigned long address) {
    long ret = ptrace(PTRACE_READ_D, pid, (void*)address, 0);
    if (ret == -1) {
        perror("ptrace read error");
    }
    return ret;
}

// Write memory at address to target process
int write_memory(pid_t pid, unsigned long address, long data) {
    int ret = ptrace(PTRACE_WRITE_D, pid, (void*)address, data);
    if (ret == -1) {
        perror("ptrace write error");
    }
    return ret;
}

// Find process ID by name in /proc
pid_t find_process(const char* target_name) {
    char cmdline[4096];
    char path[4096];
    DIR *dir = opendir("/proc");
    if (!dir) return 0;
    
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        long pid = strtol(entry->d_name, NULL, 10);
        if (pid <= 0) continue;
        
        snprintf(path, sizeof(path), "/proc/%ld/cmdline", pid);
        FILE *f = fopen(path, "r");
        if (!f) continue;
        
        if (fgets(cmdline, sizeof(cmdline), f) != NULL) {
            if (strstr(cmdline, target_name) != NULL) {
                fclose(f);
                closedir(dir);
                return (pid_t)pid;
            }
        }
        fclose(f);
    }
    closedir(dir);
    return 0;
}

// Write hook bytes at target address in target process
int write_hook(pid_t pid, unsigned long address, unsigned char* hook, int hook_len) {
    // Save original bytes
    long* orig_bytes = malloc(hook_len * sizeof(long));
    for (int i = 0; i < hook_len; i++) {
        orig_bytes[i] = read_memory(pid, address + i * sizeof(long));
    }
    
    // Write hook bytes
    for (int i = 0; i < hook_len; i++) {
        if (write_memory(pid, address + i * sizeof(long), *(long*)(hook + i)) == -1) {
            free(orig_bytes);
            return -1;
        }
    }
    
    free(orig_bytes);
    return 0;
}

// Restore original bytes
void restore_bytes(pid_t pid, unsigned long address, long* orig_bytes, int hook_len) {
    for (int i = 0; i < hook_len; i++) {
        write_memory(pid, address + i * sizeof(long), orig_bytes[i]);
    }
}
