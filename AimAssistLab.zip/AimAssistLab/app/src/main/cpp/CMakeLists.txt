cmake_minimum_required(VERSION 3.4.1)

# Extract package name from build.gradle
set(PROJECT_NAME "AimAssistLab")

add_library(memory-injector SHARED
    memory_injector.c
)

set_target_properties(memory-injector PROPERTIES
    VERSION "@PROJECT_VERSION@"
    SOVERSION "1.0"
)

# Output to appropriate ABI folder
set(CMAKE_CURRENT_OUTPUT_DIR 
    "${CMAKE_SOURCE_DIR}/../../../jniLibs/${ANDROID_ABI}")
