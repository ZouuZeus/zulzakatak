plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}

android {
    namespace "com.example.aimassistlab"
    compileSdk 35
    defaultConfig {
        applicationId "com.example.aimassistlab"
        minSdk 24
        targetSdk 35
        versionCode 1
        versionName "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    externalNativeBuild {
        cmake {
            cppFlags "-std=c++17 -frtti -fexceptions"
        }
    }
    ndk {
        abiFilters 'armeabi-v7a', 'arm64-v8a', 'x86', 'x86_64'
    }
}
